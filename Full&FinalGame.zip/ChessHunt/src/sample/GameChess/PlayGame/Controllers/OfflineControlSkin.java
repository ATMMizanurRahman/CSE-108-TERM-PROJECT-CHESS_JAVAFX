package sample.GameChess.PlayGame.Controllers;

import javafx.scene.control.Skin;
import javafx.scene.control.SkinBase;

public class OfflineControlSkin extends SkinBase<OfflineControl> implements Skin<OfflineControl> {

    public OfflineControlSkin(OfflineControl offlineControl) {
        super(offlineControl);
    }
}
