Ok...Hello...Guys.....

these shown errors have been found in several times 
when playing chess game 

I think I have some bug in with my setting/getting
Stroke

Again, there are bugs in checking Chakemates

I think there are also bugs in possiblemoves
as king sometime can go to a forbidden place
so you can eat the KING!!

but it is good that it's very little

So Feel free to remove our bugs and have a nice CHessHunt


credits->
Ahsanul Ameen Sabit 
1605047
Level-1,Term-2
CSE,BUET